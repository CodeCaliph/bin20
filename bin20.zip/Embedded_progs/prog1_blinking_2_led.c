#include <p89v51rx2.h>

void delay (unsigned int dela) {
    unsigned int i, j;
    for (i = 0; i < dela; i++) {
        for (j = 0; j < 1000; j++);
    }
}

void main() {
    while (1) {
        RxD = 0;
        TxD = 1;
        delay(500);
        RxD = 1;
        TxD = 0;
        delay(500);
    }
}