#include <p89v51rx2.h>

void delay (unsigned int dela) {
    unsigned int i, j;
    for (i = 0; i < dela; i++) {
        for (j = 0; j < 1000; j++);
    }
}

void main() {
    unsigned int count;
    while (1) {
        for (count = 0; count < 16; count++) {
            RxD = !((count & 1));
            TxD = !((count & 2) >> 1);
            RD = !((count & 4) >> 2);
            WR = !((count & 8) >> 3);
            delay(1000);
        }
    }
}