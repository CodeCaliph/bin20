// Design a system using 8051, take input from switch, implement 4-bit counter, and give buzzer output at completion.

#include <p89v51rx2.h>

void delay (unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 1275; j++); // Approximate delay for 1 ms at 12 MHz
    }
}

void main() {
    unsigned int count;
    while (1) {
        if (INT0 == 0) {
            for (count = 0; count < 16; count++) {
                RxD = !((count & 1));
                TxD = !((count & 2) >> 1);
                WR = !((count & 4) >> 2);
                RD = !((count & 8) >> 3);
                delay(5000);
            }
            // Buzzer output at completion
            P1_0 = 0; // Assuming buzzer is connected to P1.0
            delay(1000); // Buzzer on for 1 second
            P1_0 = 1; // Turn off buzzer
        }
    }
}