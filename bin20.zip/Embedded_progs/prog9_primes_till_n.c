#include <P89V51RX2.H>
#include <LCD.H>

// Switches
sbit SW1 = P3^2;
sbit SW2 = P3^3;
sbit SW3 = P3^4;
sbit SW4 = P3^5;

// LEDs
sbit RxD_LED = P3^0;
sbit TxD_LED = P3^1;
sbit WR_LED  = P3^6;
sbit RD_LED  = P3^7;

// Delay Function
void delay_ms(unsigned int ms)
{
    unsigned int i, j;

    for(i = 0; i < ms; i++)
        for(j = 0; j < 1275; j++);
}

// Prime Checking Function
bit is_prime(unsigned char num)
{
    unsigned char i;

    if(num < 2)
        return 0;

    for(i = 2; i < num; i++)
    {
        if(num % i == 0)
            return 0;
    }

    return 1;
}

void main()
{
    unsigned char N;
    unsigned char i;
    unsigned char prime_count;
    unsigned char row, col;

    char msg1[] = "Prime Nos:";
    char num1[4];
    char num2[4];

    LCD_INIT();

    while(1)
    {
        N = 0;

        // Read switches as binary input
        if(SW1 == 0)
            N += 1;

        if(SW2 == 0)
            N += 2;

        if(SW3 == 0)
            N += 4;

        if(SW4 == 0)
            N += 8;

        delay_ms(200);

        LCD_WRITE(msg1, 0, 0);

        prime_count = 0;
        row = 1;
        col = 0;

        // Find and display prime numbers
        for(i = 2; i <= N; i++)
        {
            if(is_prime(i))
            {
                prime_count++;

                // Convert number into string
                if(i >= 10)
                {
                    num2[0] = (i / 10) + '0';
                    num2[1] = (i % 10) + '0';
                    num2[2] = ' ';
                    num2[3] = '\0';
                }
                else
                {
                    num2[0] = i + '0';
                    num2[1] = ' ';
                    num2[2] = '\0';
                }

                LCD_WRITE(num2, row, col);

                col += 3;

                if(col > 12)
                {
                    row = 1;
                    col = 0;
                }

                delay_ms(300);
            }
        }

        // Display prime count on LEDs
        RxD_LED = (prime_count & 0x01);
        TxD_LED = (prime_count & 0x02) >> 1;
        WR_LED  = (prime_count & 0x04) >> 2;
        RD_LED  = (prime_count & 0x08) >> 3;

        delay_ms(1000);
    }
}