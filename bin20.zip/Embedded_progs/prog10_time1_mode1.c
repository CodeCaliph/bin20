/*
To create a 500ms delay using an 11.0592 MHz crystal, we first calculate the machine
cycle: 12/11.0592 MHz = 1.085μs. Since Timer 1 in Mode 1 (16-bit) has a maximum
count of 65536, the maximum possible single delay is ≈ 71.1 ms. Therefore, we design a
50ms delay sub-routine using Timer 1 and call it 10 times in a loop. For a 50ms delay:
50000μs/1.085μs ≈ 46082 timer ticks. The initial value to be loaded into the timer is
65536 − 46082 = 19454, which is 4BFE in hexadecimal (TH1 = 0x4B, TL1 = 0xFE). The
main program toggles pin P3.0 and calls the 500ms delay function in an infinite loop.
*/

#include < p89v51rx2 .h >

sbit out_pin = P3 ^ 0; // Define toggle pin

void T1_delay_50ms(void)
{
    TMOD = TMOD & 0 x0F; // Clear Timer 1 mode bits
    TMOD = TMOD | 0 x10; // Configure Timer 1 in Mode 1 (16 - bit Timer )
    // Load initial values for ~50 ms delay
    // (65536 - 46082) = 19454 = 0 x4BFE
    TH1 = 0 x4B ;
    TL1 = 0 xFE;
    TR1 = 1; // Start Timer 1
    while (TF1 == 0); // Wait until timer overflows ( TF1 goes high )
    TR1 = 0; // Stop Timer 1
    TF1 = 0; // Clear the overflow flag for the next cycle
}

void delay_500ms(void)
{
    unsigned char i;
    for (i = 0; i < 10; i++)
    {
        T1_delay_50ms();
    }
}

void main(void)
{
    out_pin = 0; // Initialize pin
    while (1)
    {
        out_pin = ~out_pin; // Toggle the output pin
        delay_500ms();      // Call the exact 500 ms delay
    }
}