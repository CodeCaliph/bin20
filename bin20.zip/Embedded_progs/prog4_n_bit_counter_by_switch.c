#include <p89v51rx2.h>

void delay (unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 1275; j++); // Approximate delay for 1 ms at 12 MHz
    }
}

void main() {
    unsigned int count;
    while (1) {
        if (INT0 == 0) {
            for (count = 0; count < 2; count++) {
                RxD = (count & 1);
                delay(5000);
            }
        }
        else if (INT1 == 0) {
            for (count = 0; count < 4; count++) {
                RxD = (count & 1);
                TxD = (count & 2) >> 1;
                delay(5000);
            }
        }
        else if (T0 == 0) {
            for (count = 0; count < 8; count++) {
                RxD = (count & 1);
                TxD = (count & 2) >> 1;
                WR = (count & 4) >> 2;
                delay(5000);
            }
        }
        else if (T1 == 0) {
            for (count = 0; count < 16; count++) {
                RxD = (count & 1);
                TxD = (count & 2) >> 1;
                WR = (count & 4) >> 2;
                RD = (count & 8) >> 3;
                delay(5000);
            }
        }
    }
}