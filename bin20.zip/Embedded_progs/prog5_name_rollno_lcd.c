#include <p89v51rx2.h>

void delay (unsigned int dela) {
    unsigned int i, j;
    for (i = 0; i < dela; i++) {
        for (j = 0; j < 1000; j++);
    }
}

void main() {
    LCD_INIT();
    while (1) {
        LCD_WRITE_STRING("Name: Your Name", 0, 0);
        LCD_WRITE_STRING("Roll No: Your Roll No", 1, 0);
        delay(2000);
        while(1);
    }
}