#include <LCD.H>

sbit switch4 = P3 ^ 2; // INT0 SW1
sbit switch3 = P3 ^ 3; // INT1 SW2
sbit switch2 = P3 ^ 4; // T0 SW3
sbit switch1 = P3 ^ 5; // T1 SW4
unsigned long int factorial(unsigned char n)
{
    unsigned long int num = 1;
    while (n != 0)
    {
        num *= n;
        n--;
    }
    return num;
}
char *reverse(char *str, int len)
{
    int i = 0;
    char temp;
    while (i != len / 2)
    {
        temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;

        i++;
    }
    return str;
}
int conv(char *str, unsigned long int number)
{
    int i = 0;
    while (number != 0)
    {
        str[i] = '0' + number % 10;
        number /= 10;
        i++;
    }
    str[i] = '\0';
    reverse(str, i);

    return i;
}
void main()
{
    unsigned char text[16] = "Factorial of ";
    unsigned char switch_val = 0;
    unsigned char n = 0;
    int len;
    LCD_INIT();
    LCD_WRITE("Fact. of 0 is", 0, 0);
    LCD_WRITE("1", 1, 3);
    while (1)
    {
        if (switch1 == 0 || switch2 == 0 || switch3 == 0 ||
            switch4 == 0)

            switch_val = 0;
        if (switch1 == 0) // check if switch 1 is pressed
            switch_val += 1, n = switch_val;
        if (switch2 == 0) // check if switch 2 is pressed
            switch_val += 2, n = switch_val;
        if (switch3 == 0) // check if switch 3 is pressed
            switch_val += 4, n = switch_val;
        if (switch4 == 0)
            switch_val += 8, n = switch_val;

        if (n == 0)
            continue;

        LCD_WRITE(" ", 0, 0);
        LCD_WRITE("Fact. of ", 0, 0);
        len = conv(text, n);
        LCD_WRITE(text, 0, 9);
        LCD_WRITE(" is", 0, 9 + len);

        LCD_WRITE(" ", 1, 0);
        conv(text, factorial(n));
        LCD_WRITE(text, 1, 3);

        delay(50);
        n = 0;
    }
}