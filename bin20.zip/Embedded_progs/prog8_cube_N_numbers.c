// To design and implement an Embedded System that displays the cube of first N numbers (N - input through switch) on LCD screen 8051 board.

#include <p89v51rx2.h>
#include <LCD.H>

sbit switch4 = P3 ^ 2; // INT0 SW1
sbit switch3 = P3 ^ 3; // INT1 SW2
sbit switch2 = P3 ^ 4; // T0 SW3
sbit switch1 = P3 ^ 5; // T1 SW4

unsigned long int cube(unsigned char n)
{
    return n * n * n;
}

void main()
{
    unsigned char text[16] = "Cube of ";
    unsigned char switch_val = 0;
    unsigned char n = 0;
    int len;
    LCD_INIT();
    LCD_WRITE("Cube of 0 is", 0, 0);
    LCD_WRITE("0", 1, 3);
    while (1)
    {
        if (switch1 == 0 || switch2 == 0 || switch3 == 0 ||
            switch4 == 0)

            switch_val = 0;
        if (switch1 == 0) // check if switch 1 is pressed
            switch_val = 1;
        else if (switch2 == 0) // check if switch 2 is pressed
            switch_val = 2;
        else if (switch3 == 0) // check if switch 3 is pressed
            switch_val = 3;
        else if (switch4 == 0) // check if switch 4 is pressed
            switch_val = 4;

        n = switch_val;
        for (int i = 1; i <= n; i++ ) {
            text = "Cube of ";
            len = conv(text + 8, i);
            LCD_WRITE(text, 0, 0);
            len = conv(text, cube(i));
            LCD_WRITE(text, 1, 0);
            delay(1000);
        }
        
    }
}