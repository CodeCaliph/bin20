# Goal State
GOAL = (
    (1, 2, 3),
    (4, 5, 6),
    (7, 8, 0)
)

# Moves: Up, Down, Left, Right
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]


class Node:
    def __init__(self, board, blank_pos, g, parent=None):
        self.board = board
        self.blank = blank_pos
        self.g = g
        self.h = self.manhattan()
        self.f = self.g + self.h
        self.parent = parent

    def manhattan(self):
        dist = 0
        for i in range(3):
            for j in range(3):
                val = self.board[i][j]
                if val != 0:
                    gi = (val - 1) // 3
                    gj = (val - 1) % 3
                    dist += abs(i - gi) + abs(j - gj)
        return dist


def print_board(board):
    for row in board:
        print(row)
    print("------")


def print_solution(node):
    path = []
    while node:
        path.append(node.board)
        node = node.parent
    path.reverse()

    for step in path:
        print_board(step)


def find_blank(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == 0:
                return i, j


def solve_8_puzzle_astar(start):
    open_list = []
    visited = set()

    blank = find_blank(start)
    start_node = Node(start, blank, 0)
    open_list.append(start_node)
    visited.add(start)

    while open_list:
        current = min(open_list, key=lambda n: n.f)
        open_list.remove(current)

        if current.board == GOAL:
            print("Goal State Reached\n")
            print_solution(current)
            return

        x, y = current.blank

        for dx, dy in MOVES:
            nx, ny = x + dx, y + dy
            if 0 <= nx < 3 and 0 <= ny < 3:
                new_board = [list(r) for r in current.board]
                new_board[x][y], new_board[nx][ny] = \
                    new_board[nx][ny], new_board[x][y]

                new_board = tuple(tuple(r) for r in new_board)

                if new_board not in visited:
                    visited.add(new_board)
                    open_list.append(
                        Node(new_board, (nx, ny), current.g + 1, current)
                    )

    print("No solution found")

if __name__ == "__main__":
    initial_state = (
        (1, 2, 3),
        (4, 0, 5),
        (6, 7, 8)
    )

    print("Initial State:")
    print_board(initial_state)

    solve_8_puzzle_astar(initial_state)