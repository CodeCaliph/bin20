def diagnose():
    print("Enter symptoms (yes/no):")

    fever = input("Fever? ").lower()
    cough = input("Cough? ").lower()
    headache = input("Headache? ").lower()
    fatigue = input("Fatigue? ").lower()
    cold = input("Cold? ").lower()

    print("\nDiagnosis Result:")

    if fever == "yes" and cough == "yes" and fatigue == "yes":
        print("You may have Flu.")

    elif fever == "yes" and headache == "yes":
        print("You may have Viral Fever.")

    elif cold == "yes" and cough == "yes":
        print("You may have Common Cold.")

    elif headache == "yes" and fatigue == "yes":
        print("You may have Migraine.")

    else:
        print("Symptoms unclear. Please consult a doctor.")


# Driver Code
diagnose()
