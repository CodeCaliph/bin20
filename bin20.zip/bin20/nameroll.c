#include <LCD.h> 
 
 unsigned char x = 3, y = 0; 
 
 void main(void) { 
  LCD_INIT(); // Initialize LCD 
   
  while(1) { 
      // Display Name on the first line (y=0) 
         LCD_WRITE("AFFAN", 0, 0); 
       
      // Display Roll Number on the second line (y=1) 
         LCD_WRITE("ROLL: 23BCS050", 1, 0); 
       
         while(1) { 
          // Infinite loop to keep display static 
      } 
  } 
 }