import numpy as np
import matplotlib.pyplot as plt
class Perceptron:
    def __init__(self, n, lr=0.1, epochs=15):
        self.w = np.zeros(n)
        self.b = 0
        self.lr = lr
        self.epochs = epochs
        self.errors = []
    def predict(self, x):
        y_in = np.dot(x, self.w) + self.b
        return 1 if y_in >= 0 else 0
    def train(self, X, y):
        for _ in range(self.epochs):
            error_sum = 0
            for i in range(len(X)):
                pred = self.predict(X[i])
                error = y[i] - pred
                self.w += self.lr * error * X[i]
                self.b += self.lr * error
                error_sum += error ** 2
            self.errors.append(error_sum / len(X))
X = np.array([[0,0,0],[0,0,1],[0,1,0],[0,1,1], [1,0,0],[1,0,1],[1,1,0],[1,1,1]])
y = np.array([0,0,0,0,0,0,0,1])
p = Perceptron(3)
p.train(X, y)
print("Weights:", p.w)
print("Bias:", p.b)
plt.plot(p.errors)
plt.title("AND Gate")
plt.xlabel("Epoch")
plt.ylabel("Error")
plt.grid()
plt.show()
# for OR gate y = np.array([0,1,1,1,1,1,1,1])