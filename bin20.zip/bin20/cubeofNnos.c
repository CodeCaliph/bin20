#include <p89v51rx2.h> 
 #include <stdio.h> 
 #include <LCD.h> 
 
 void delay(unsigned int dela) { 
  unsigned int i, j; 
  for(i = 0; i <= 1000; i++) 
      for(j = 0; j <= dela; j++); 
 } 
 
 void main(void) { 
  unsigned char N, i; 
  unsigned long cube; 
  char buffer1[16]; 
  char buffer2[16]; 
 
  LCD_INIT(); // Initialize LCD module 
   
  // Configure P1.0-P1.3 as inputs by writing 1s to them 
  P1 = P1 | 0x0F; 
 
  while(1) { 
      // Read 4-bit input N from switches 
      N = P1 & 0x0F; 
       
      if (N == 0) { 
             LCD_WRITE("Enter N > 0     ", 0, 0); 
             LCD_WRITE("                ", 1, 0); 
             delay(100); 
      } else { 
          // Loop through the first N numbers 
             for(i = 1; i <= N; i++) { 
                 cube = (unsigned long)i * i * i; 
 
                 // Format data into strings (padding spaces clear old characters) 
                 sprintf(buffer1, "Num: %d         ", (int)i); 
                 sprintf(buffer2, "Cube: %lu       ", cube); 
 
                 // Display results on LCD 
                 LCD_WRITE(buffer1, 0, 0); // Display on line 1 
                 LCD_WRITE(buffer2, 1, 0); // Display on line 2 
                 
                 // Delay to allow the user to read the current cube 
                 delay(500); 
          } 
          // Longer pause before restarting the sequence 
             delay(1000); 
      } 
  } 
 }