n = 3
a = [[1, 2, 3],[4, 5, 6],[7, 8, 9]]
b = [[9, 8, 7],[6, 5, 4],[3, 2, 1]]
add = []
for i in range(n):
    row = []
    for j in range(n):
        row.append(a[i][j] + b[i][j])
    add.append(row)
mul = []
for i in range(n):
    row = []
    for j in range(n):
        s = 0
        for k in range(n):
            s += a[i][k] * b[k][j]
        row.append(s)
    mul.append(row)
# Means
add_sum = 0
mul_sum = 0
for i in range(n):
    for j in range(n):
        add_sum += add[i][j]
        mul_sum += mul[i][j]
print("Addition Matrix:")
for row in add:
    print(row)
print("Addition Mean =", add_sum / (n * n))
print("\nMultiplication Matrix:")
for row in mul:
    print(row)
print("Multiplication Mean =", mul_sum / (n * n))