import math

# Game tree representation
tree = {
    'ROOT': ['A', 'B', 'C'],
    'A': [3, 5],
    'B': [1, 2],
    'C': [5, 8]
}

pruned = []

def alphabeta(node, depth, alpha, beta, maximizing):
    # If leaf node (integer)
    if isinstance(node, int):
        return node

    if maximizing:
        value = -math.inf
        for child in tree[node]:
            val = alphabeta(child, depth+1, alpha, beta, False)
            value = max(value, val)
            alpha = max(alpha, value)

            if beta <= alpha:
                # prune remaining children
                remaining = tree[node][tree[node].index(child)+1:]
                pruned.extend(remaining)
                break

        return value

    else:
        value = math.inf
        for child in tree[node]:
            val = alphabeta(child, depth+1, alpha, beta, True)
            value = min(value, val)
            beta = min(beta, value)

            if beta <= alpha:
                remaining = tree[node][tree[node].index(child)+1:]
                pruned.extend(remaining)
                break

        return value


# Driver Code
optimal_value = alphabeta('ROOT', 0, -math.inf, math.inf, True)

print("Optimal Value:", optimal_value)
print("Pruned Nodes:", pruned)
