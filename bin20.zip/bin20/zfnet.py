import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow import keras
from tensorflow.keras import layers
(X_train, y_train), (X_test, y_test) = tf.keras.datasets.fashion_mnist.load_data()
def process(image, label):
    image = tf.expand_dims(image, -1)
    image = tf.image.grayscale_to_rgb(image)
    image = tf.image.resize(image, [224, 224])
    image = tf.cast(image, tf.float32) / 255.0
    return image, label
batch = 64
train_ds = tf.data.Dataset.from_tensor_slices((X_train, y_train))
train_ds = train_ds.map(process).batch(batch)
test_ds = tf.data.Dataset.from_tensor_slices((X_test, y_test))
test_ds = test_ds.map(process).batch(batch)
model = keras.Sequential([
    layers.Input(shape=(224,224,3)),
    layers.Conv2D(96, (7,7), strides=2, activation='relu'),
    layers.MaxPooling2D((3,3), strides=2),
    layers.Conv2D(256, (5,5), strides=2, padding='same', activation='relu'),
    layers.MaxPooling2D((3,3), strides=2),
    layers.Conv2D(512, (3,3), padding='same', activation='relu'),
    layers.Conv2D(1024, (3,3), padding='same', activation='relu'),
    layers.Conv2D(512, (3,3), padding='same', activation='relu'),
    layers.MaxPooling2D((3,3), strides=2),
    layers.Flatten(),
    layers.Dense(4096, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(4096, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(10, activation='softmax')])
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'])
history = model.fit(
    train_ds,
    epochs=5,
    validation_data=test_ds)
loss, acc = model.evaluate(test_ds)
print("Test Accuracy =", acc)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.legend(['Train', 'Test'])
plt.title("ZFNet Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.grid()
plt.show()