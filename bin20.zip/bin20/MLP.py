import numpy as np
import matplotlib.pyplot as plt
X = np.array([[0, 0],[0, 1],[1, 0],[1, 1]])
y = np.array([-1, 1, 1, -1])
def step(x):
    return np.where(x >= 0, 1, -1)
np.random.seed(1)
Wh = np.random.uniform(-1, 1, (2, 2))   # Hidden weights
Wo = np.random.uniform(-1, 1, 2)        # Output weights
bh = np.random.uniform(-1, 1, 2)        # Hidden bias
bo = np.random.uniform(-1, 1)           # Output bias
lr = 0.1
epochs = 20
errors = []
for epoch in range(epochs):
    total_error = 0
    for i in range(len(X)):
        h_in = np.dot(Wh, X[i]) + bh
        h_out = step(h_in)
        o_in = np.dot(Wo, h_out) + bo
        out = step(o_in)
        if out != y[i]:
            k = np.argmin(abs(h_in))
            error = y[i] - h_out[k]
            Wh[k] += lr * error * X[i]
            bh[k] += lr * error
            total_error += abs(error)
    errors.append(total_error)
plt.plot(errors)
plt.title("XOR Training Error")
plt.xlabel("Epoch")
plt.ylabel("Error")
plt.grid()
plt.show()
print("Predictions:\n")
for i in range(len(X)):
    h = step(np.dot(Wh, X[i]) + bh)
    pred = step(np.dot(Wo, h) + bo)
    print(X[i], "->", pred)