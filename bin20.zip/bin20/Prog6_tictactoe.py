import math

board = [' ' for _ in range(9)]

def print_board():
    print()
    for i in range(3):
        print(board[3*i], "|", board[3*i+1], "|", board[3*i+2])
        if i < 2:
            print("--+---+--")
    print()

def check_winner(b, player):
    win_pos = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]
    for pos in win_pos:
        if all(b[i] == player for i in pos):
            return True
    return False

def is_full(b):
    return ' ' not in b

def minimax(b, depth, is_max):
    if check_winner(b, 'O'):
        return 1
    if check_winner(b, 'X'):
        return -1
    if is_full(b):
        return 0

    if is_max:
        best = -math.inf
        for i in range(9):
            if b[i] == ' ':
                b[i] = 'O'
                score = minimax(b, depth+1, False)
                b[i] = ' '
                best = max(best, score)
        return best
    else:
        best = math.inf
        for i in range(9):
            if b[i] == ' ':
                b[i] = 'X'
                score = minimax(b, depth+1, True)
                b[i] = ' '
                best = min(best, score)
        return best

def best_move():
    best_val = -math.inf
    move = -1
    for i in range(9):
        if board[i] == ' ':
            board[i] = 'O'
            move_val = minimax(board, 0, False)
            board[i] = ' '
            if move_val > best_val:
                move = i
                best_val = move_val
    return move

def play():
    print("Tic-Tac-Toe Game")
    print("You are X, AI is O")

    while True:
        print_board()

        # Human move
        move = int(input("Enter position (1-9): ")) - 1
        if board[move] != ' ':
            print("Invalid move!")
            continue

        board[move] = 'X'

        if check_winner(board, 'X'):
            print_board()
            print("You Win!")
            break

        if is_full(board):
            print_board()
            print("Draw!")
            break

        # AI move
        ai_move = best_move()
        board[ai_move] = 'O'

        if check_winner(board, 'O'):
            print_board()
            print("AI Wins!")
            break

        if is_full(board):
            print_board()
            print("Draw!")
            break

play()
