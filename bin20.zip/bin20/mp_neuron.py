import numpy as np
class MPNeuron:
    def __init__(self, weights, threshold):
        self.weights = np.array(weights)
        self.threshold = threshold
    def predict(self, x):
        y_in = np.dot(x, self.weights)
        return np.where(y_in >= self.threshold, 1, 0)
    def accuracy(self, x, target):
        y = self.predict(x)
        print("Predictions:", y)
        print("Targets:    ", target)
        return np.mean(y == target)
x = np.array([[0, 0],[0, 1],[1, 0],[1, 1]])
and_target = np.array([0, 0, 0, 1])
and_neuron = MPNeuron([1, 1], 2)
print("AND Gate")
acc = and_neuron.accuracy(x, and_target)
print("Accuracy =", acc * 100, "%")
or_target = np.array([0, 1, 1, 1])
or_neuron = MPNeuron([1, 1], 1)
print("\nOR Gate")
acc = or_neuron.accuracy(x, or_target)
print("Accuracy =", acc * 100, "%")