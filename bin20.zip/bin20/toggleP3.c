#include <p89v51rx2.h> 
 
 sbit out_pin = P3^0; // Define toggle pin 
 
 // Function to generate exact 50ms delay using Timer 1 Mode 1 
 void T1_delay_50ms(void) { 
  TMOD = TMOD & 0x0F; // Clear Timer 1 mode bits 
  TMOD = TMOD | 0x10; // Configure Timer 1 in Mode 1 (16-bit Timer) 
   
  // Load initial values for ~50ms delay 
  // (65536 - 46082) = 19454 = 0x4BFE 
  TH1 = 0x4B; 
  TL1 = 0xFE; 
   
  TR1 = 1; // Start Timer 1 
  while(TF1 == 0); // Wait until timer overflows (TF1 goes high) 
  TR1 = 0; // Stop Timer 1 
  TF1 = 0; // Clear the overflow flag for the next cycle 
 } 
 
 // Function to generate 500ms delay by looping 50ms ten times 
 void delay_500ms(void) { 
  unsigned char i; 
  for(i = 0; i < 10; i++) { 
         T1_delay_50ms(); 
  } 
 } 
 
 void main(void) { 
  out_pin = 0; // Initialize pin 
   
  while(1) { 
      out_pin = ~out_pin; // Toggle the output pin 
 
         delay_500ms();   // Call the exact 500ms delay 
  } 
 }