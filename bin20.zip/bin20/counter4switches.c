#include <p89v51rx2.h> 
 
 void delay(unsigned int dela) { 
  unsigned int i, j; 
  for(i = 0; i <= 1000; i++) 
      for(j = 0; j <= dela; j++); 
 } 
 
 void main(void) { 
  unsigned int i, j; 
  while(1) { 
      if(INT0 == 0) { // 1-bit Counter 
             for(i = 0; i < 2; i++) { 
                 RxD = !((1 << 0) & i); 
                 delay(100); 
          } 
      } 
      else if(INT1 == 0) { // 2-bit Counter 
             for(i = 0; i < 4; i++) { 
                 RxD = !((1 << 0) & i); 
                 TxD = !((1 << 1) & i); 
                 delay(100); 
          } 
      } 
      else if(T0 == 0) { // 3-bit Counter 
             for(i = 0; i < 8; i++) { 
                 RxD = !((1 << 0) & i); 
 
                 TxD = !((1 << 1) & i); 
                 WR = !((1 << 2) & i); 
                 delay(100); 
          } 
      } 
      else if(T1 == 0) { // 4-bit Counter 
             for(i = 0; i < 16; i++) { 
                 RxD = !((1 << 0) & i); 
                 TxD = !((1 << 1) & i); 
              WR = !((1 << 2) & i); 
                 RD = !((1 << 3) & i); 
                 delay(100); 
          } 
      } 
      // Reset all LEDs to OFF 
      RxD = 1; TxD = 1; WR = 1; RD = 1; 
  } 
 }