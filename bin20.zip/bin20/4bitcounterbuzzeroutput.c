#include <p89v51rx2.h> 
 
 void delay(unsigned int dela) { 
  unsigned int i, j; 
  for(i = 0; i <= 1000; i++) 
      for(j = 0; j <= dela; j++); 
 } 
 
 void main(void) { 
  unsigned int i; 
  P1_5 = 1; // Ensure Buzzer is OFF initially (Active Low) 
   
  while(1) { 
      if(INT0 == 0) { // Wait for switch press 
             for(i = 0; i < 16; i++) { 
                 RxD = !((1 << 0) & i); 
                 TxD = !((1 << 1) & i); 
                 WR = !((1 << 2) & i); 
                 RD = !((1 << 3) & i); 
                 delay(100); 
          } 
           
          // Turn ON buzzer upon completion 
             P1_5 = 0; 
             delay(200); // Buzzer duration 
             P1_5 = 1; // Turn OFF buzzer 
           
          // Reset all LEDs to OFF 
          RxD = 1; TxD = 1; WR = 1; RD = 1; 
      } 
  } 
 }