#include <p89v51rx2.h> 
 #include <stdio.h> 
 #include <LCD.h> 
 
 void delay(unsigned int dela) { 
  unsigned int i, j; 
  for(i = 0; i <= 1000; i++) 
      for(j = 0; j <= dela; j++); 
 } 
 
 void main(void) { 
  unsigned char input_num, i; 
  unsigned long factorial; 
  char buffer1[16]; 
  char buffer2[16]; 
 
  LCD_INIT(); // Initialize LCD module 
   
  // Configure P1.0-P1.3 as inputs by writing 1s to them 
  P1 = P1 | 0x0F; 
 
  while(1) { 
      // Read 4-bit binary input from switches and mask upper bits 
         input_num = P1 & 0x0F; 
       
      // Compute factorial 
 
         factorial = 1; 
      for(i = 1; i <= input_num; i++) { 
             factorial *= i; 
      } 
 
      // Format data into strings 
         sprintf(buffer1, "Number: %d", (int)input_num); 
         sprintf(buffer2, "Fact: %lu", factorial); 
 
      // Display results on LCD 
      // LCD_WRITE(string, line, column) 
         LCD_WRITE(buffer1, 0, 0); // Display on line 1 
         LCD_WRITE(buffer2, 1, 0); // Display on line 2 
       
         delay(100); // Short delay to prevent LCD flickering 
  } 
 } 