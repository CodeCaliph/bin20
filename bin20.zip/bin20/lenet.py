import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from tensorflow import keras
from tensorflow.keras import layers
train = pd.read_csv("/kaggle/input/competitions/digit-recognizer/train.csv")
X = train.drop("label", axis=1).values / 255.0
y = train["label"].values
X = X.reshape(-1, 28, 28, 1)
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.1, random_state=42)
X_train = np.pad(X_train, ((0,0),(2,2),(2,2),(0,0)))
X_val = np.pad(X_val, ((0,0),(2,2),(2,2),(0,0)))
model = keras.Sequential([
    layers.Input(shape=(32,32,1)),
    layers.Conv2D(6, (5,5), activation='tanh'),
    layers.AveragePooling2D(),
    layers.Conv2D(16, (5,5), activation='tanh'),
    layers.AveragePooling2D(),
    layers.Conv2D(120, (5,5), activation='tanh'),
    layers.Flatten(),
    layers.Dense(84, activation='tanh'),
    layers.Dense(10, activation='softmax')])
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)
history = model.fit(
    X_train,
    y_train,
    validation_data=(X_val, y_val),
    epochs=5,
    batch_size=64
)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.legend(['Train', 'Validation'])
plt.title("Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.show()
loss, acc = model.evaluate(X_val, y_val)
print("Validation Accuracy =", acc)