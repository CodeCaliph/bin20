import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required resources (run once)
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

text = "Together is easy but To+get+her is very hard"

# Step 1: Lowercase
text = text.lower()
print("Lowercase Text:\n", text)

# Step 2: Tokenization
tokens = word_tokenize(text)
print("\nTokens:\n", tokens)

# Step 3: Stopword Removal
stop_words = set(stopwords.words('english'))
filtered_tokens = [word for word in tokens if word not in stop_words]
print("\nAfter Stopword Removal:\n", filtered_tokens)

# Step 4: Stemming
ps = PorterStemmer()
stemmed = [ps.stem(word) for word in filtered_tokens]
print("\nAfter Stemming:\n", stemmed)

# Step 5: Lemmatization
lemmatizer = WordNetLemmatizer()
lemmatized = [lemmatizer.lemmatize(word) for word in filtered_tokens]
print("\nAfter Lemmatization:\n", lemmatized)
