class Node:
    def __init__(self, name, h=0, goal=False, dead=False):
        self.n = name
        self.h = h
        self.goal = goal
        self.dead = dead
        self.sol = goal
        self.conn = []
        self.best = None

    def add(self, typ, ch, cost):
        self.conn.append({"t": typ, "ch": ch, "c": cost})


class AOStar:
    def __init__(self):
        self.nodes = {}

    def add_node(self, n, h=0, goal=False, dead=False):
        self.nodes[n] = Node(n, h, goal, dead)

    def add_conn(self, p, typ, ch, cost):
        self.nodes[p].add(typ, ch, cost)

    def cost(self, con):
        c = con["c"]
        ch = con["ch"]

        if con["t"] == "OR":
            val = c + self.nodes[ch[0]].h
            print(f"   OR -> {ch[0]} | Cost = {c} + {self.nodes[ch[0]].h} = {val}")
            return val
        else:
            val = sum(c + self.nodes[x].h for x in ch)
            details = " + ".join(f"({c}+{self.nodes[x].h})" for x in ch)
            print(f"   AND -> {ch} | Cost = {details} = {val}")
            return val

    def update(self, n):
        node = self.nodes[n]

        if node.goal:
            node.h = 0
            node.sol = True
            return

        if node.dead:
            return

        print(f"\nExpanding Node: {n}")

        best = None
        best_cost = float("inf")

        for con in node.conn:
            cost_val = self.cost(con)
            if cost_val < best_cost:
                best_cost = cost_val
                best = con

        node.best = best
        node.h = best_cost

        if best["t"] == "OR":
            node.sol = self.nodes[best["ch"][0]].sol
        else:
            node.sol = all(self.nodes[x].sol for x in best["ch"])

        print(f"   Updated h({n}) = {node.h}")
        print(f"   Status: {'SOLVED' if node.sol else 'OPEN'}")

    def propagate(self):
        changed = True

        while changed:
            changed = False
            old = {n: (self.nodes[n].h, self.nodes[n].sol) for n in self.nodes}

            for n in self.nodes:
                self.update(n)

            new = {n: (self.nodes[n].h, self.nodes[n].sol) for n in self.nodes}

            if old != new:
                changed = True

    def tip(self, start):
        cur = self.nodes[start]

        while True:
            if cur.goal:
                return None

            if not cur.sol:
                if cur.best is None:
                    return cur.n

                for c in cur.best["ch"]:
                    if not self.nodes[c].sol:
                        return c

                return cur.n

            return None

    def solve(self, start):
        while not self.nodes[start].sol:
            t = self.tip(start)

            if t is None:
                break

            node = self.nodes[t]

            if node.goal:
                node.sol = True
                node.h = 0
            elif not node.dead:
                self.update(t)

            self.propagate()

    def print_sol(self, n, lvl=0):
        node = self.nodes[n]
        print("  " * lvl + n)

        if node.best is None:
            return

        for c in node.best["ch"]:
            self.print_sol(c, lvl + 1)


# INPUT GRAPH

g = AOStar()

g.add_node("A", 12)
g.add_node("B", 8)
g.add_node("C", 4)
g.add_node("D", 3)

g.add_node("E", 6, dead=True)
g.add_node("F", 9, dead=True)

g.add_node("G", 0, goal=True)
g.add_node("H", 0, goal=True)
g.add_node("I", 0, goal=True)

g.add_node("J", 5, dead=True)

g.add_conn("A", "OR", ["B"], 1)
g.add_conn("A", "AND", ["C", "D"], 1)

g.add_conn("B", "OR", ["E"], 2)
g.add_conn("B", "OR", ["F"], 1)

g.add_conn("C", "AND", ["G", "H"], 1)

g.add_conn("D", "OR", ["I"], 1)
g.add_conn("D", "OR", ["J"], 2)

# RUN AO*

g.solve("A")

print("\nFinal Heuristic Values:")
for n in g.nodes:
    print(f"{n} : h = {g.nodes[n].h}")

print("\nOptimal Solution Subgraph:")
g.print_sol("A")
