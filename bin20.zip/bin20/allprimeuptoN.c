#include <p89v51rx2.h> 
 #include <stdio.h> 
 #include <LCD.h> 
 
 sbit BUZZ = P0^3; // Define Buzzer Pin 
 
 void delay(unsigned int dela) { 
  unsigned int i, j; 
  for(i = 0; i <= 1000; i++) 
      for(j = 0; j <= dela; j++); 
 } 
 
 // Function to check if a number is prime 
 unsigned char is_prime(unsigned char num) { 
  unsigned char i; 
  if(num < 2) return 0; 
  for(i = 2; i <= num / 2; i++) { 
      if(num % i == 0) return 0; 
  } 
  return 1; 
 } 
 
 void main(void) { 
  unsigned char lower_nibble, upper_nibble, N, i, prime_count; 
 
 
 32 
 
  char buffer[16]; 
 
  LCD_INIT(); // Initialize LCD module 
  P1 = P1 | 0x0F; // Configure P1.0-P1.3 as inputs 
  BUZZ = 1; // Turn off buzzer initially (Active Low) 
 
  while(1) { 
         prime_count = 0; 
      P3 = 0xFF; // Turn off all LEDs (Active Low assumption) 
 
      // Read Lower Nibble 
         LCD_WRITE("Set Lower Nibble", 0, 0); 
         delay(3000); // 3 second delay to allow user to set switches 
         lower_nibble = P1 & 0x0F; 
 
      // Sound Buzzer between nibbles 
      BUZZ = 0; 
         delay(200); 
      BUZZ = 1; 
 
      // Read Upper Nibble 
         LCD_WRITE("Set Upper Nibble", 0, 0); 
         delay(3000); // 3 second delay to allow user to set switches 
         upper_nibble = P1 & 0x0F; 
 
      // Construct 8-bit N 
      N = (upper_nibble << 4) | lower_nibble; 
 
      // Display N 
         sprintf(buffer, "N = %d          ", (int)N); 
         LCD_WRITE(buffer, 0, 0); 
         LCD_WRITE("Finding Primes..", 1, 0); 
         delay(1000); 
 
      // Find and display prime numbers 
      for(i = 2; i <= N; i++) { 
             if(is_prime(i)) { 
                 prime_count++;                  
                 // Update LEDs with prime count (inverted for Active Low LEDs) 
                 P3 = ~prime_count; 
 
                 // Display current prime on LCD 
                 sprintf(buffer, "Prime: %d        ", (int)i); 
                 LCD_WRITE(buffer, 1, 0); 
                 delay(800); // Delay to visualize the sequence 
          } 
      } 
       
         LCD_WRITE("Done!           ", 1, 0); 
         delay(3000); // Hold before restarting 
  } 
 }