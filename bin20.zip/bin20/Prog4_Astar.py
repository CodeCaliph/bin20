import heapq

# Graph definition
graph = {
    'S': [('A', 4), ('C', 3)],
    'A': [('B', 5), ('C', 12)],
    'B': [('G', 16)],
    'C': [('D', 7), ('E', 10)],
    'D': [('E', 2)],
    'E': [('G', 5)],
    'G': []
}

# Heuristic values
h = {
    'S': 14,
    'A': 12,
    'B': 11,
    'C': 11,
    'D': 6,
    'E': 4,
    'G': 0
}

def astar(start, goal):
    open_list = []
    heapq.heappush(open_list, (h[start], 0, start, []))
    visited = set()

    while open_list:
        f, g, node, path = heapq.heappop(open_list)

        if node in visited:
            continue

        path = path + [node]
        visited.add(node)

        if node == goal:
            return path, g

        for neighbor, cost in graph[node]:
            if neighbor not in visited:
                heapq.heappush(
                    open_list,
                    (g + cost + h[neighbor], g + cost, neighbor, path)
                )

    return None, float('inf')


path, cost = astar('S', 'G')

print("Optimal Path:", " -> ".join(path))
print("Total Cost:", cost)
