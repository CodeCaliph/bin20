#include <p89v51rx2.h> 
 
 // Function to generate delay 
 void delay(unsigned int del) { 
  unsigned int i, j; 
  for (i = 0; i <= 1000; i++) { 
      for (j = 0; j <= del; j++); 
  } 
 } 
 
 void main(void) { 
  while (1) { 
      // RxD (P3.0) and TxD (P3.1) are mapped to these LEDs 
      P3_0 = 0; // First LED ON 
      P3_1 = 1; // Second LED OFF 
         delay(20); 
       
      P3_0 = 1; // First LED OFF 
      P3_1 = 0; // Second LED ON 
         delay(20); 
  } 
 } 