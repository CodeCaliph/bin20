#include <p89v51rx2.h> 
 
 // Function to handle bit decrement logic 
 void decr(int arr[4]) { 
  int i; 
  for(i = 0; i < 4; i++) { 
         if(arr[i] == 1) { 
             arr[i] = 0; 
             return; 
      } else { 
             arr[i] = 1; 
      } 
  } 
 } 
 
 // Function to generate delay 
 void delay(unsigned int d) { 
  unsigned int i, j; 
  for(i = 0; i < 1000; i++) { 
      for(j = 0; j < d; j++); 
  } 
 } 
 
 void main(void) { 
  int arr[4] = {1, 1, 1, 1}; // Starting from 1111 for reverse counter 
  while (1) { 
      // Map array bits to specific LED pins 
      P3_0 = arr[3]; // RxD LED 
      P3_1 = arr[2]; // TxD LED 
      P3_6 = arr[1]; // WR LED 
      P3_7 = arr[0]; // RD LED 
       
         delay(100); 
 
         decr(arr); 
  } 
 }