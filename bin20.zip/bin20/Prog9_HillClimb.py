def f(x):
    return -(x**2 - 6*x + 9)

def hill_climbing(start, step):
    current_x = start
    current_val = f(current_x)

    while True:
        next_x1 = current_x + step
        next_x2 = current_x - step

        val1 = f(next_x1)
        val2 = f(next_x2)

        # Choose best neighbor
        if val1 > current_val:
            current_x = next_x1
            current_val = val1
        elif val2 > current_val:
            current_x = next_x2
            current_val = val2
        else:
            break

    return current_x, current_val


# Driver Code
x, max_val = hill_climbing(0, 0.5)

print("Maximum value found at x =", x)
print("Maximum value f(x) =", max_val)
